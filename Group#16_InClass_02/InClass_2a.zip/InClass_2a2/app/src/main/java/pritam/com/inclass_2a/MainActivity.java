/*
    Assignment #.   - In class 2
    File Name.      - 2a_Main Activity
    Group Members   - Pritam Jayram Borate
                      Thomas Neil Kattampallil
 */


package pritam.com.inclass_2a;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button euro= (Button) findViewById(R.id.euro);
        Button cad= (Button) findViewById(R.id.cad);
        Button gbp= (Button) findViewById(R.id.gbp);
        Button jpy= (Button) findViewById(R.id.jpy);
        Button clearAll= (Button) findViewById(R.id.clearAll);
        euro.setOnClickListener(this);
        cad.setOnClickListener(this);
        gbp.setOnClickListener(this);
        jpy.setOnClickListener(this);
        clearAll.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        DecimalFormat df2 = new DecimalFormat(".##");
        EditText usdAmount = (EditText) findViewById(R.id.usdAmount);
        //EditText convertedCurrency = (EditText) findViewById(R.id.convertedCurrencey);
        TextView result = (TextView) findViewById(R.id.result);
        Double usd = Double.valueOf(0);

        Log.d("Value","Button clicked is "+v.getId());
        if (v.getId() == R.id.clearAll) {
            //convertedCurrency.setText("");
            result.setText("");
            usdAmount.setText("");
        }
        else if(!(usdAmount.getText().toString().equals("")))
        {
            String amount=usdAmount.getText().toString();
            if(amount.contains(".")) {
                if (amount.substring(amount.indexOf("."), amount.length()).length()-1 > 2) {
                    Log.w("Warning", "Decimal is greater than 2");
                    Toast.makeText(getApplicationContext(), "Amount should have only 2 digits after decimal point", Toast.LENGTH_SHORT).show();
                    usd=Double.valueOf(1);
                }
                else
                    usd=Double.parseDouble(usdAmount.getText().toString());
            }
            else
                usd=Double.parseDouble(usdAmount.getText().toString());
            if(usd==1)
            {
                Log.w("Float", ""+usd);
                //convertedCurrency.setText("");
                result.setText("");
                //Toast.makeText(getApplicationContext(),"Please enter amount for conversion!",Toast.LENGTH_SHORT).show();
            }
            else {
                if (v.getId() == R.id.euro) {
                   // convertedCurrency.setText(usdAmount.getText() + " USD = " + df2.format(usd * 0.849282)+ " EUR");
                    result.setText(usdAmount.getText() + " USD = " + df2.format(usd * 0.849282)+ " EUR");
                } else if (v.getId() == R.id.cad) {
                    //convertedCurrency.setText(usdAmount.getText() + " USD = " + df2.format(usd * 1.19) +" CAD");
                    result.setText(usdAmount.getText() + " USD = " + df2.format(usd * 1.19) +" CAD");
                } else if (v.getId() == R.id.gbp) {
                    //convertedCurrency.setText(usdAmount.getText() + " USD = " + df2.format(usd * 0.65)+ " GBP");
                    result.setText(usdAmount.getText() + " USD = " + df2.format(usd * 0.65)+ " GBP");
                } else if (v.getId() == R.id.jpy) {
                   // convertedCurrency.setText(usdAmount.getText() + " USD = " + df2.format(usd * 117.62)+ " JPY");
                    result.setText(usdAmount.getText() + " USD = " + df2.format(usd * 117.62)+ " JPY");
                }
            }

        }
        else
        {
            Log.w("Float", ""+usd);
            Toast.makeText(getApplicationContext(),"Please enter amount for conversion!",Toast.LENGTH_SHORT).show();
            //convertedCurrency.setText("");
            result.setText("");
        }


        //convertedCurrency.setText(usdAmount.getText() +" USD = "+usd*0.849282);
    }
}
