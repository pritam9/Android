/*
    Assignment #.   - In class 2
    File Name.      - 2b_Main Activity
    Group Members   - Pritam Jayram Borate
                      Thomas Neil Kattampallil
 */
package com.example.inclass2b;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    int option;
    double value;
    DecimalFormat df2 = new DecimalFormat(".##");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup rg= (RadioGroup)findViewById(R.id.radioGroup);
        option=R.id.Eur;
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
            RadioButton rb=(RadioButton)findViewById(checkedId);
                option =rb.getId();
            }
        });
        Button btn= (Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                TextView Result=(TextView)findViewById(R.id.result);
                EditText enteredValue=(EditText)findViewById(R.id.USD);
                if (option == R.id.Clear) {

                    Result.setText("");
                    enteredValue.setText("1");
                    RadioButton eur=(RadioButton)findViewById(R.id.Eur);
                    eur.toggle();

                }else{
                   String amount=enteredValue.getText().toString();
                    if(amount.equals(""))
                        Toast.makeText(getApplicationContext(), "Enter amount", Toast.LENGTH_SHORT).show();
                    else if(amount.contains(".")) {
                       if (amount.substring(amount.indexOf("."), amount.length()).length()-1 > 2) {
                           Log.w("Warning", "Decimal is greater than 2");
                           Toast.makeText(getApplicationContext(), "Amount should have only 2 digits after decimal point", Toast.LENGTH_SHORT).show();
                           value=Double.valueOf(0);
                       }
                       else
                           value=Double.parseDouble(enteredValue.getText().toString());
                   }
                   else
                       value = Double.parseDouble(enteredValue.getText().toString());


                   if(value==0) {

                   }
                    else if (option == R.id.Eur) {

                           Result.setText(enteredValue.getText() + " USD = " + df2.format(value * 0.849282) + " EUR");

                       }

                   else if (option == R.id.Can) {

                       Result.setText(enteredValue.getText() + " USD = " + df2.format(value * 1.19) + " CAD");

                   }
                   else if (option == R.id.Gre) {

                       Result.setText(enteredValue.getText() + " USD = " + df2.format(value * 0.65) + " GBP");

                   }
                   else if (option == R.id.Jap) {

                       Result.setText(enteredValue.getText() + " USD = " + df2.format(value * 117.62) + " JPY");

                   }


               }

            }
        });
    }


}
